Codex 0.157.1 third-party attribution

These are preserved original notices, published package metadata and source-header
files for a conservative CLI dependency graph. It includes build/development and
other-platform packages. It is not an exact binary SBOM. Source code in this archive
is inert attribution evidence, not installed runtime code. No source is relicensed.

Each registry package has its original Cargo.toml. THIRD-PARTY.json maps original
paths to preserved bytes/checksums. upstream-candidates contains exact upstream
notices; provenance records their repository/revision/path and crate VCS mappings.

The standard-terms directory holds unmodified SPDX license templates. A template's
placeholder copyright line is not an assertion about any package. Existing actual
copyright notices are preserved in their original files and source headers.

For debugserver-types 0.5.0, fax 0.2.6 and fax_derive 0.2.0, the exact published
Cargo manifest declares MIT but no separate copyright notice was found in the
original archives or pinned source. Original archives and authorship metadata are
retained in THIRD-PARTY-SOURCES.zip and THIRD-PARTY.json. Do not interpret author
metadata as a newly asserted copyright holder/year. The license declaration and
standard MIT terms are preserved without fabricating a missing notice.

Difflib 0.4.0's six published Rust files match the recorded later immutable source
with its original MIT notice. A later fax notice was NOT substituted.

Where a package offers alternatives, Fort uses Apache-2.0 when offered, otherwise MIT, otherwise the original permissive license. AND clauses retain all conjuncts. MPL-only components remain MPL-2.0. All collected original notices are preserved even when another allowed alternative is chosen. Termina sources are included conservatively despite its MIT alternative.
